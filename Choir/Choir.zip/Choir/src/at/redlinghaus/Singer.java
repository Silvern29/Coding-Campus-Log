package at.redlinghaus;

public interface Singer {
    public void sing();
}
