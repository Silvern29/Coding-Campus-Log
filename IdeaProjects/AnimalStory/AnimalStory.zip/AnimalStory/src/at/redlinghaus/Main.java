package at.redlinghaus;

public class Main {

    public static void main(String[] args) {
        StoryInTheWoods story = new StoryInTheWoods();

        story.play();
    }
}


