package at.redlinghaus;

public class Honey extends Food {

    public Honey(String name, double height, double width, double length, double weight) {
        super(name, height, weight, width, length);
    }
}
