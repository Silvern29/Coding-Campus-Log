package at.redlinghaus;

public class EagleFood extends Food {

    public EagleFood(String name, double height, double width, double length, double weight) {
        super(name, height, width, length, weight);
    }
}
