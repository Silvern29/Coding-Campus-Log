package at.redlinghaus;

public class Main {

    public static void main(String[] args) {
        Game myGame = new Game();
        myGame.play();
    }
}
