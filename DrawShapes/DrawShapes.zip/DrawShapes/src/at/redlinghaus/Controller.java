package at.redlinghaus;

public class Controller {
}
