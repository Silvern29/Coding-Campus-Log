package at.redlinghaus;

public interface Resizable {
    public void resize(double percent);
}
